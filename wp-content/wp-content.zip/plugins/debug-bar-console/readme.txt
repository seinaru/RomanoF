=== Debug Bar Console ===
Contributors: koopersmith
Tags: debug, developer, console
Tested up to: 3.4
Stable tag: 0.3
Requires at least: 3.1

Adds a PHP/MySQL console to the debug bar. Requires the debug bar plugin.

== Description ==

Adds a PHP/MySQL console to the debug bar. Requires the [Debug Bar plugin](http://wordpress.org/extend/plugins/debug-bar/) (v0.5 or later).

== Upgrade Notice ==

= 0.3 =
Added syntax highlighting using the CodeMirror text editor.
Explicit PHP/SQL modes.
UI changes to reflect updated debug bar UI.

= 0.2 =
Improvements to MySQL detection and display.
Bug fixes.

= 0.1 =
Initial Release

== Changelog ==

= 0.3 =
Added syntax highlighting using the CodeMirror text editor.
Explicit PHP/SQL modes.
UI changes to reflect updated debug bar UI.

= 0.2 =
Improvements to MySQL detection and display.
Bug fixes.

= 0.1 =
Initial Release

== Installation ==

Install the [Debug Bar plugin](http://wordpress.org/extend/plugins/debug-bar/).

Use automatic installer.
