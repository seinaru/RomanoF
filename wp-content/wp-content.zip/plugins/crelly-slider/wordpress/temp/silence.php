<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php // If you can read this, you probably have never used the Import/Export function ?>